TCG EXPRESS - VEHICLE DECAL ARTWORK
Production files for cut vinyl. Issue 2, 19 Aug 2026.

FILES (SVG units are MILLIMETRES = real finished size)
  TCG_SIDE_L_3600mm.svg    24ft box lorry, side   3600 x 811 mm
  TCG_SIDE_M_2600mm.svg    14ft box lorry, side   2600 x 585 mm
  TCG_SIDE_S_1500mm.svg    van, side              1500 x 338 mm
  TCG_REAR_L_1200mm.svg    24ft box lorry, rear   1200 x 706 mm
  TCG_REAR_M_900mm.svg     14ft box lorry, rear    900 x 630 mm
  TCG_REAR_S_600mm.svg     van, rear               600 x 453 mm

HOW TO READ THESE FILES
  - No scaling needed. 1 SVG unit = 1 mm.
  - ALL TEXT IS ALREADY CONVERTED TO OUTLINES. You do not need any font.
  - Two colour layers, named inside the file:
        <g id="BLUE-279C">   -> Pantone 279 C vinyl
        <g id="WHITE">       -> white vinyl
  - Both sides of a vehicle use the same SIDE file.

LETTER HEIGHTS (measured, mm)
  Tier          wordmark   strapline   contact line   logo mark
  L  (24ft)        294        122           105        581 x 523
  M  (14ft)        212         88            76        419 x 378
  S  (van)         122         51            46        242 x 218
  Rear L           103          -            41 (SCAN line)   203 x 183
  Rear M            77          -            31             152 x 137
  Rear S            51          -            21             101 x  91

CHARACTER COUNT FOR CUTTING (excluding spaces)
  Side panel   "TCG EXPRESS"                              10
               "IT & TECH EQUIPMENT DELIVERY"             24
               "+65 8976 3771 . app.techchainglobal.com"  35
               subtotal per side panel                    69  + 1 logo mark
  Rear panel   "TCG EXPRESS"                              10
               "SCAN TO BOOK A DELIVERY"                  19
               subtotal rear                              29  + 1 logo mark

  PER VEHICLE (2 sides + rear) = 167 cut characters + 3 logo marks
                               + 1 printed QR panel
  The logo mark is 2 chevron shapes, solid, no fine detail.

COLOURS
  Blue    Pantone 279 C   (#4DA3FF on screen)
  White   plain white vinyl

THE QR PANEL - READ THIS
  On the REAR files the QR area is drawn as a MAGENTA DASHED BOX.
  That box is a PLACEHOLDER, not artwork.
  It is NOT cut vinyl. It is a PRINTED, UV-LAMINATED panel applied on top.
  Sizes: 400 x 400 mm on L and M, 300 x 300 mm on S.
  A QR code cannot be produced in cut vinyl - the modules will not weed and
  will lift on application. Please quote that one panel separately.
  Final QR artwork will be supplied once the destination URL is fixed.

SINGLE COLOUR OPTION
  If quoting single colour, use all WHITE and ignore the blue layer.
  Please give us both prices.

CONTACT
  Scott - TCG Express, Tech Chain Global Pte Ltd (UEN 202005872W)
  admin@techchainglobal.com  |  +65 8976 3771
